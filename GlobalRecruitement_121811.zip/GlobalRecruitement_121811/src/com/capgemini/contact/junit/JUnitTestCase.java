package com.capgemini.contact.junit;

public class JUnitTestCase {

}
