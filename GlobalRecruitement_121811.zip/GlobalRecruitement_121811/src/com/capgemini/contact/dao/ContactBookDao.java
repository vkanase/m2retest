package com.capgemini.contact.dao;

import com.capgemini.contact.bean.EnquiryBean;
import com.capgemini.contact.exception.ContactBookException;

public interface ContactBookDao 
{
	
	public int addEnquiry(EnquiryBean enqry) throws ContactBookException;
	public EnquiryBean getEnquiryDetails(int EnquiryID) throws ContactBookException;

}