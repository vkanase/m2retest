package com.capgemini.contact.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.contact.bean.EnquiryBean;
import com.capgemini.contact.exception.ContactBookException;
import com.capgemini.contact.util.DBUtil;

public class ContactBookDaoImpl implements ContactBookDao {

	static Logger myLogger;
	public ContactBookDaoImpl() {

		PropertyConfigurator.configure("log4j.properties");
		myLogger = Logger.getLogger(ContactBookDaoImpl.class.getName());

	}
	@Override
	public int addEnquiry(EnquiryBean enqry) throws ContactBookException {
		int generatedId = -1;
		try(Connection con = DBUtil.getConnection())
		{
			
			Statement stm = con.createStatement();
			ResultSet res = stm.executeQuery(" select enquiries.nextVal from dual");

			if(res.next() == false)
				throw new ContactBookException("Something went wrong");

			int enqryId = res.getInt(1);

			String fName = enqry.getfName();
			String lName = enqry.getiName();
			String contactNo = enqry.getContactNo();
			String pLocation = enqry.getpLocation();
			String pDomain = enqry.getpDomain();
			
			PreparedStatement pstm = con.prepareStatement("insert into enquiry values(?,?,?,?,?,?)");

			pstm.setInt(1, enqryId);
			pstm.setString(2, fName);
			pstm.setString(3, lName);
			pstm.setString(4, contactNo);
			pstm.setString(5, pLocation);
			pstm.setString(6, pDomain);
			
			pstm.execute();
			
			generatedId = enqryId;
			myLogger.info("Contact added successfull");

		}

		catch (SQLException e)
		{

			e.printStackTrace();
			myLogger.error(e.getMessage());

			throw new ContactBookException(e.getMessage());

		}
		catch(Exception e)
		{

			throw new ContactBookException(e.getMessage());
		}

		return generatedId;
	}
	@Override
	public EnquiryBean getEnquiryDetails(int EnquiryID)
			throws ContactBookException {

		// TODO Auto-generated method stub
		EnquiryBean enquirybean = null;
		try(Connection con = DBUtil.getConnection())
		{

			PreparedStatement pstm = con.prepareStatement("select * from enquiry where enqryId=?");
			pstm.setInt(1, EnquiryID);

			ResultSet res = pstm.executeQuery();
			if(res.next() == false)

				throw new ContactBookException("No such Contact found"+ EnquiryID);

			enquirybean = new EnquiryBean();
			enquirybean.setEnqryid(res.getInt("enqryId"));
			enquirybean.setfName(res.getString("firstName"));
			enquirybean.setiName(res.getString("lastName"));
			enquirybean.setContactNo(res.getString("contactNo"));
			enquirybean.setpLocation(res.getString("city"));
			enquirybean.setpDomain(res.getString("doamin"));

			myLogger.info("Contact get successfull");
		}

		catch(SQLException e)
		{

			e.printStackTrace();
			myLogger.error(e.getMessage());

			throw new ContactBookException(e.getMessage());
		}

		catch(Exception e)
		{
			e.printStackTrace();

			throw new ContactBookException(e.getMessage());
		}

		return enquirybean;
	}
}