package com.capgemini.contact.service;

import java.util.regex.Pattern;

import com.capgemini.contact.bean.EnquiryBean;
import com.capgemini.contact.dao.ContactBookDao;
import com.capgemini.contact.dao.ContactBookDaoImpl;
import com.capgemini.contact.exception.ContactBookException;

public class ContactBookServiceImpl implements ContactBookService {

private ContactBookDao bookDao;
public ContactBookServiceImpl() {

	bookDao=new ContactBookDaoImpl();
}
	@Override
	public int addEnquiry(EnquiryBean enqry) throws ContactBookException {
		
		return bookDao.addEnquiry(enqry);
	}
	@Override
	public EnquiryBean getEnquiryDetails(int EnquiryID)
			throws ContactBookException {
		return bookDao.getEnquiryDetails(EnquiryID);
	}

	@Override
	public boolean isValidEnquiry(EnquiryBean enqry)
			throws ContactBookException
	{
		boolean flag = false;
		if(validateFirstName(enqry.getfName()))
		{

			if(validateLastName(enqry.getiName()))
			{

				if(validateContactNo(enqry.getContactNo()))
				{

					if(validatePDomain(enqry.getpDomain()))
					{
						if(validatePLocation(enqry.getpLocation()))
						{

							flag = true;
						}
					}
				}
			}
		}
		return flag;
	}
	public static boolean validateFirstName(String fname) throws ContactBookException
	{
		
		String patt="^[A-Z]{1}[a-z]{19}";
		boolean value=Pattern.matches(patt,fname);
		if(value){

			return true;
		}
		else{

			return false;
		}
	}
	public static boolean validateLastName(String lname) throws ContactBookException
	{
		String patt="^[A-Z]{1}[a-z]{19}";
		boolean value=Pattern.matches(patt,lname);
		if(value){
			return true;
		}
		else{

			return false;
		}
	}
	public static boolean validateContactNo(String contactno) throws ContactBookException
	{

		String patt="^[7-9]{1}[0-9]{9}";
		boolean value=Pattern.matches(patt,contactno);
		if(value){

				return true;
		}

		else{

			return false;
		}
	}

	public static boolean validatePLocation(String pLocation) throws ContactBookException
	{

		String patt="^[A-Z]{1}[a-z]{19}";
		boolean value=Pattern.matches(patt,pLocation);
		if(value){

			return true;
		}

		else{

			return false;
		}
	}

	public static boolean validatePDomain(String pDomain) throws ContactBookException
	{

		String patt="^[A-Z]{1}[a-z]{19}";

		boolean value=Pattern.matches(patt,pDomain);
		if(value){

			return true;
		}
		else{

			return false;
		}
	}
}