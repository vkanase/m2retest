package com.capgemini.contact.service;

import com.capgemini.contact.bean.EnquiryBean;
import com.capgemini.contact.exception.ContactBookException;

public interface ContactBookService {

	public int addEnquiry(EnquiryBean enqry) throws ContactBookException;
	public EnquiryBean getEnquiryDetails(int EnquiryID) throws ContactBookException;
	public boolean isValidEnquiry(EnquiryBean enqry) throws ContactBookException;

}