package com.capgemini.contact.ui;

import java.util.Scanner;

import com.capgemini.contact.bean.EnquiryBean;
import com.capgemini.contact.service.ContactBookService;
import com.capgemini.contact.service.ContactBookServiceImpl;

public class Client {

private ContactBookService bookservice;

Scanner sc = new Scanner(System.in);

public Client() {

	bookservice = new ContactBookServiceImpl();
	
	}

	public static void main(String[] args) {

		Client bookUI = new Client();

		while (true) {

			bookUI.viewMenu();

		}

	}

	private void viewMenu() {

		Scanner sc = new Scanner(System.in);

		System.out.println("Choose an Operation");

		System.out.println("1. Enter Enquiry Details");

		System.out.println("2. View Enquiry Details On ID");

		System.out.println("0. Exit");

		System.out.println("Please select your choice");

		int choice = sc.nextInt();

		switch (choice) {

		case 1:

			addEnquiry();

			break;

		case 2:

			getEnquiryDetails();

			break;

		case 0:

			System.out.println("ThankYou ! Exiting App...");

			System.exit(0);

			break;

		default:

			System.out.println("Invalid Input");

			break;

		}

	}

	private void addEnquiry() {

		System.out.println("Enter First Name");

		String firstName=sc.next();

		System.out.println("Enter Last Name");

		String lastName=sc.next();

		System.out.println("Enter Contact Number");

		String contactNo=sc.next();

		System.out.println("Enter Preferred Domain");

		String preDomain=sc.next();
		
		System.out.println("Enter Preferred Location");
		
		String pLocation=sc.next();
		
		EnquiryBean enqbean=new EnquiryBean();
		
		enqbean.setfName(firstName);
		
		enqbean.setiName(lastName);
		
		enqbean.setContactNo(contactNo);
		
		enqbean.setpDomain(preDomain);
		
		enqbean.setpLocation(pLocation);
		
		int id=bookservice.addEnquiry(enqbean);
		
		System.out.println("Thank You "+firstName+" "+lastName+" Your Unique Id is "+id);

	}

	private void getEnquiryDetails() {

		System.out.println("Enter the Enquiry No:");

		int enquiryNo=sc.nextInt();

		EnquiryBean bean=bookservice.getEnquiryDetails(enquiryNo);

		System.out.println("Id First Name \tLast Name \t Contact No: \t Preffered domain \t Preffered Location");

		System.out.println(bean.getEnqryid()+" \t"+bean.getfName()+"\t\t"+bean.getiName()+"\t\t"+bean.getContactNo()+"\t"+bean.getpDomain()+"\t\t\t"+bean.getpLocation());

	}

}